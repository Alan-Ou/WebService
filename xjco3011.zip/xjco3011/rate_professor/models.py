from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.contrib.auth.models import User


# Professor
class Professor(models.Model):
    # A unique identifier
    id = models.CharField(primary_key=True, unique=True, max_length=3)
    name = models.CharField(max_length=64, default='xxx')

    def __str__(self):
        return f"{self.name} ({self.id})"


# Module
class Module(models.Model):
    # A unique identifier
    code = models.CharField(primary_key=True, unique=True, max_length=3)
    name = models.CharField(max_length=64, default='xxx')

    def __str__(self):
        return f"{self.name} ({self.code})"


# Module instance
class ModuleInstance(models.Model):
    # 多对多关系
    professors = models.ManyToManyField(Professor, blank=False)
    # 多对一关系
    module = models.ForeignKey(Module, on_delete=models.CASCADE)

    academic_year = models.IntegerField(validators=[MinValueValidator(2000), MaxValueValidator(2022)])
    # The semester should be in the range 1-2
    semester = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(2)])

    def __str__(self):
        return "Name:{0} (Code:{1}) Year:{2} Semester:{3}".format(self.module.code, self.module.name,
                                                                  self.academic_year, self.semester)


# Rating
class Rating(models.Model):
    # 多对一关系
    professor = models.ForeignKey(Professor, on_delete=models.CASCADE)
    module_instance = models.ForeignKey(ModuleInstance, on_delete=models.CASCADE)
    # The rating should be in the range 1-5
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])

    # The rating of Professor V. Smart (VS1) in module Computing for Dummies (CD1) is ***
    def __str__(self):
        return "The rating of Professor {0} ({1}) in module {2} ({3}) is {4}".format(self.professor.name,
                                                                                     self.professor.id,
                                                                                     self.module_instance.module.name,
                                                                                     self.module_instance.module.code,
                                                                                     self.rating)
