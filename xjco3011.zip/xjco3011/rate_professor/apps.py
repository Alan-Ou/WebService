from django.apps import AppConfig


class RateProfessorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rate_professor'
