from django.urls import path
from .views import *

urlpatterns = [
    path('register/', register),
    path('login/', login),
    path('logout/', logout),
    path('modules/', view_modules),
    path('rating/professors/', view_professors),
    path('rating/professor/module/', average_professor),
    path('post/rate/', rate),
]
