from statistics import mean, StatisticsError

import requests
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import IntegrityError
from .models import Professor, ModuleInstance, Module, Rating
import math
from .functions import get_prof_rating, cal_avg_rating

is_login = False


# Register to the service
@csrf_exempt
def register(request):
    if request.method == 'POST':
        account_info = request.body.decode('utf-8')
        account = json.loads(account_info)
        try:
            username = account['username']
            email = account['email']
            password = account['password']

            user = User.objects.create_user(username=username, email=email, password=password)

        except IntegrityError:
            return HttpResponse("\nUser Already exists", status=400)

        user.save()
        return HttpResponse("\nYour account has been created successfully", status=200)
    else:
        return HttpResponse("\nBad request, please try again", status=400)


# Log in to the service
@csrf_exempt
def login(request):
    if request.method == 'POST':
        account_info = request.body.decode('utf-8')
        account = json.loads(account_info)
        username = account['username']
        password = account['password']

        # Authenticate the user
        user = auth.authenticate(request, username=username, password=password)
    else:
        return HttpResponse('Bad request', status=400)

    if user is not None and user.is_active:
        auth.login(request, user)
        return HttpResponse("\nSuccessfully log in", status=200)
    else:
        return HttpResponse("\nFailed, please try again", status=400)


# Log out from the service
@csrf_exempt
def logout(request):
    auth.logout(request)
    return HttpResponse("\nSuccessfully log out", status=200)


# View a list of all module instances and the professor(s) teaching each of them.
def view_modules(request):
    users = User.objects.all()
    if len(users) == 1:
        return HttpResponse("\nNo log in yet", status=404)
    else:
        # All module instances
        module_instances = ModuleInstance.objects.all()
        data_info = []
        for module_instance in module_instances:
            prof_names = []
            professors = module_instance.professors.all()
            for professor in professors:
                prof_names.append(professor.id + ', Professor ' + professor.name)

            module_info = {
                'module_code': module_instance.module.code,
                'module_name': module_instance.module.name,
                'academic_year': module_instance.academic_year,
                'semester': module_instance.semester,
                'professors': prof_names
            }

            data_info.append(module_info)
        json_str = json.dumps(data_info)

        return HttpResponse(json_str, status=200)


# View the rating of all professors
def view_professors(request):
    # All professors
    professors = Professor.objects.all()
    output = []
    for professor in professors:
        score = get_prof_rating(professor.id)
        star = "*" * score
        output.append(f"The rating of {professor.name} is {star}")

    jason_str = json.dumps(output)
    return HttpResponse(jason_str, status=200)


# View the average rating of a certain professor in a certain module
@csrf_exempt
def average_professor(request):
    if request.method == 'POST':
        package = json.loads(request.body.decode('utf-8'))
    else:
        return HttpResponse(status=400)

    prof_id = package['prof_id']
    mod_code = package['mod_code']

    try:
        professor = Professor.objects.get(id=prof_id)
    except Professor.DoesNotExist:
        return HttpResponse(status=401)

    try:
        module = Module.objects.get(code=mod_code)
    except Module.DoesNotExist:
        return HttpResponse(status=402)

    star = "*" * cal_avg_rating(prof_id, mod_code)
    data_info = f"\nThe rating for {professor.name} in module {module.name} is {star}"

    json_str = json.dumps(data_info)
    return HttpResponse(json_str, status=200)


# Rate the teaching of a certain professor in a certain module instance
@csrf_exempt
def rate(request):
    if request.method == 'POST':
        package = json.loads(request.body.decode('utf-8'))
    else:
        return HttpResponse(status=400)

    # Check rating within bounds, professor exists and module code exists
    if int(package['rating']) > 5 or int(package['rating']) < 1:
        return HttpResponse(status=401)

    # Find professor object
    professors = Professor.objects.all()
    prof_obj = None
    for professor in professors:
        if professor.id == package['prof_id']:
            prof_obj = professor
            break
    if prof_obj is None:
        return HttpResponse(status=402)

    # Find module object
    modules = Module.objects.all()
    mod_obj = None
    for module in modules:
        if module.code == package['mod_code']:
            mod_obj = module
            break
    if mod_obj is None:
        return HttpResponse(status=403)

    # Find module instance object
    mod_ins_obj = ModuleInstance.objects.get(module=mod_obj, academic_year=package['year'],
                                             semester=package['semester'])

    if mod_ins_obj is None:
        return HttpResponse(status=404)

    # Create a new rating object
    rating = Rating(rating=package['rating'], professor=prof_obj, module_instance=mod_ins_obj)
    rating.save()

    return HttpResponse(status=200)
