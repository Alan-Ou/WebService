import requests
import json
from prettytable import PrettyTable
from decimal import *

# requests.session():维持会话,可以让我们在跨请求时保存某些参数
# 实例化session
session = requests.session()

# url
url_online = ''
url = 'http://127.0.0.1:8000/'


def help():
    table = PrettyTable(['Command', 'Description'])

    table.add_row(["help", "Way to use this service"])
    table.add_row(["register", "Register to the service"])
    table.add_row(["login", "Log in to the service"])
    table.add_row(["logout", "Logout from the service"])
    table.add_row(["list", "View a list of all module instances and the professor(s) teaching each of them"])
    table.add_row(["view", "View the rating of all professors"])
    table.add_row(
        ["average <prof_code> <mod_code>", "View the average rating of a certain professor in a certain module"])
    table.add_row(["rate <prof_code> <mod_code> <year> <semester> <rating>",
                   "Rate the teaching of a certain professor in a certain module instance"])

    # 设置表的对齐方式
    table.align["Command"] = 'l'
    table.align["Description"] = 'l'

    print(table)


# This is used to allow a user to register to the service
def register():
    # 用户信息
    username = input("\nEnter a username: ")
    email = input("\nEnter an email: ")
    password = input("\nEnter a password: ")

    if len(username) == 0 or len(email) == 0 or len(password) == 0:
        print("\nThe given fields must be set")

    else:
        register_url = url + 'register/'
        register_info = {
            'username': username,
            'email': email,
            'password': password
        }
        json_str = json.dumps(register_info)
        response = requests.post(register_url, data=json_str)

        if response.status_code == 200:
            print(response.text)
        else:
            print(response.text)


# Log in to the service
def login():
    username = input("\nEnter a username: ")
    password = input("\nEnter a password: ")

    if len(username) == 0 or len(password) == 0:
        print("\nThe given fields must be entered")
    else:
        login_url = url + 'login/'
        login_info = {
            'username': username,
            'password': password
        }
        json_str = json.dumps(login_info)
        response = requests.post(login_url, data=json_str)

        if response.status_code == 200:
            print(response.text)
        else:
            print(response.text)


# This causes the user to logout from the current session
def logout():
    logout_url = url + 'logout/'
    response = session.post(logout_url)
    if response.status_code == 200:
        print(response.text)
    else:
        print("\nSomething went wrong")


# This is used to view a list of all module instances and the professor(s) teaching each of them
def list():
    list_url = url + 'modules/'
    response = session.get(list_url)

    if response.status_code == 200:
        data_info = json.loads(response.text)

        table = PrettyTable(['Code', 'Name', 'Year', 'Semester', 'Taught by'])

        for data in data_info:
            code = data['module_code']
            name = data['module_name']
            year = str(data['academic_year'])
            semester = str(data['semester'])
            p_name = ""

            for professor in data['professors']:
                p_name += professor + ". "

            table.add_row([code, name, year, semester, p_name])

        # 设置对齐方式
        # table.align["Code"] = 'l'

        print(table)
    else:
        print(response.text)


# This command is used to view the rating of all professors
def view():
    view_url = url + 'rating/professors/'
    response = session.get(view_url)
    if response.status_code == 200:
        print("\n".join(response.json()))
    else:
        print("\nFailed, please try again")


# This command is used to view the average rating of a certain professor in a certain module
# Usage: average professor_id module_code
def average(cmd):
    # out: The rating of Professor V. Smart (VS1) in module Computing for Dummies (CD1) is ***
    cmd = cmd.split()
    professor_id = cmd[1]
    module_code = cmd[2]

    average_url = url + 'rating/professor/module/'
    info = {
        "prof_id": professor_id,
        "mod_code": module_code,
    }
    json_str = json.dumps(info)
    response = requests.post(average_url, data=json_str)

    if response.status_code == 200:
        print(response.json())

    elif response.status_code == 400:
        print("\nBad request")
    elif response.status_code == 401:
        print('\nUnknown professor id')
    elif response.status_code == 402:
        print("\nUnknown module code")
    else:
        print("\nSomething went wrong. Please try again")


# This is used to rate the teaching of a certain professor in a certain module instance
# Usage: rate prof_id mod_code year semester rating
def rate(cmd):
    cmd = cmd.split()
    prof_id = cmd[1]
    mod_code = cmd[2]
    year = cmd[3]
    semester = cmd[4]
    rating = cmd[5]

    rate_url = url + 'post/rate/'
    info = {
        "prof_id": prof_id,
        "mod_code": mod_code,
        "year": year,
        "semester": semester,
        "rating": rating
    }
    json_str = json.dumps(info)
    # print(json_str)
    response = requests.post(rate_url, data=json_str)
    if response.status_code == 200:
        print("\nRated successfully")
    elif response.status_code == 400:
        print("\nBad request")
    elif response.status_code == 401:
        print("\nRating should be in range of 1 to 5")
    elif response.status_code == 402:
        print("\nUnknown professor id")
    elif response.status_code == 403:
        print("\nUnknown module code")
    elif response.status_code == 404:
        print("\nUnknown module instance")
    else:
        print("\nFailed, please try again")


def user_input(cmd):
    if cmd == 'register':
        register()

    elif cmd == 'login':
        login()

    elif cmd == 'logout':
        logout()

    elif cmd == 'list':
        list()

    elif cmd == 'view':
        view()

    elif cmd.startswith('average'):
        average(cmd)

    elif cmd.startswith('rate'):
        rate(cmd)

    elif cmd == 'help':
        help()

    elif cmd == 'q':
        exit(0)


def main_loop():
    while True:
        command = input("\nEnter your command (E.g. help): ")
        user_input(command)


if __name__ == "__main__":
    main_loop()
