from .models import Professor, ModuleInstance, Rating


def get_prof_rating(professor_id):
    ratings = Rating.objects.all()
    if len(ratings) == 0:
        return "\nNo rating yet"
    score = 0
    cnt = 0
    for rating in ratings:
        if rating.professor.id == professor_id:
            score += rating.rating
            cnt += 1

    if score == 0 and cnt == 0:
        return score

    score /= cnt
    # norm
    score = int(score + 0.5)

    return score


def cal_avg_rating(prof_id, mod_id):
    ratings = Rating.objects.all()
    if len(ratings) == 0:
        return "No rating yet"
    avg = 0
    cnt = 0
    for rating in ratings:
        if rating.professor.id == prof_id and rating.module_instance.module.code == mod_id:
            avg += rating.rating
            cnt += 1
    if avg == 0 or cnt == 0:
        return avg
    avg /= cnt
    # norm
    avg = int(avg + 0.5)
    return avg


def inner(*args, **kwargs):
    # 判断是否登录
    username = args[0].session.get("login_user", "")
    if username == "":
        # 保存当前的url到session中
        args[0].session["path"] = args[0].path
        # 重定向到登录页面
        return 0
    return 1
